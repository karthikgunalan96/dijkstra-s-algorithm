# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 20:49:28 2018

@author: Gunalan KC
"""
#author:Karthik Gunalan

def find_shortest_path(graph):# this part does the algorithm part
    edge = [0]*len(graph)
    distance = [10**4]*len(graph)# sum array initialized to maximum as said in step 4 of the document report
    distance[0] = 0
    check = [False]*len(graph)# check array initialized to maximum as said in step 4 of the document report
    for i in range(len(graph)):
        minimum = 10**4
        for j in range(len(graph)):
            if distance[j]!=10**4 and check[j] is False:
                if distance[j] < minimum:
                    minimum= distance[j]
                    minj = j
            check[minj] = True
        
        for j in range(len(graph)):
            if graph[minj][j] != 10**4 and graph[minj][j]+distance[minj] < distance[j]:#step 6
                distance[j]= graph[minj][j]+distance[minj]
                edge[j] = minj
        
    print(distance)
    print(edge)
    return distance, edge

def fetch_user_input():
    print("Enter Details")#Step 1 as per the document report
    graph = list()
    while(True):
        inp = input("")
        if inp=="":
            break
        graph.append(inp.split(","))
    return graph

def get_complete_graph(graph):
    v = list()
    for g in graph:#step 2 of the document report of storing the edge values in a an adjacency matrix
        v.append(g[0])
        v.append(g[1])
    unique_v = set(v)
    unique_v = sorted(set(v))
    global map_v_n 
    global map_n_v 
    i=0
    for s in unique_v:
        map_v_n[s]=i
        map_n_v[i]=s 
        i+=1
    new_graph = list()
    for i in range(len(unique_v)):
        new_graph.append([10**4]*len(unique_v))
    
    for i in graph:
        s=i[0]
        e=i[1]
        val=int(i[2])
        new_graph[map_v_n[s]][map_v_n[e]] = val
        new_graph[map_v_n[e]][map_v_n[s]] = val
        
    for i in range(len(new_graph)):
        new_graph[i][i]= 0
    
    print(new_graph)
    return new_graph

def print_path(d, e):
    for i in range(1, len(d)):#Step 7 printing the output
        n=i
        t=list()
        while(n != 0):
            t.append(n)
            n=e[n]
        rt=[]
        for n in reversed(t):
            rt.append(map_n_v[n])
        op = "A->"+map_n_v[i]+" "+str(tuple(rt))+" "+str(d[i])
        print(op)

def djkstras():
    graph = fetch_user_input()
    graph = get_complete_graph(graph)
    print(graph)
    d,e = find_shortest_path(graph)
    print_path(d,e)
    


    
    
map_v_n = {}
map_n_v = {}
djkstras()